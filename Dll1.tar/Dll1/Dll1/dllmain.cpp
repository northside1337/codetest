// dllmain.cpp : Defines the entry point for the DLL application.
#include "pch.h"
#include "globals.h"

void error_message(const char* msg)
{
    MessageBoxA(nullptr, msg, "Error", MB_OK | MB_ICONERROR);
}

DWORD WINAPI MainThread(LPVOID lpParam)
{
    SetConsoleTitleW(L"finally rich");

    if (!service_is_load())
    {
        error_message("load drievr nigga");
        return 1;
    }

    HWND window_handle = nullptr;

    while (!(window_handle = FindWindowW(nullptr, L"Counter-Strike")))
    {
        Sleep(1000);
    }

    MessageBoxA(nullptr, "found", "syrianpotroshitel", MB_OK);

    // Apply screenshot protection
    NTSTATUS status = protect_sprite_content_ex(window_handle, WDA_EXCLUDEFROMCAPTURE);

    if (status == 0)
    {
        MessageBoxA(nullptr, "success", "syrianpotroshitel", MB_OK);
    }
    else
    {
        error_message("fail");
    }

    // Keep the thread alive so the DLL stays loaded
    while (true)
    {
        Sleep(1000); // Sleep to prevent CPU usage
    }

    return 0;
}

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
        DisableThreadLibraryCalls(hModule);  // Prevents unnecessary thread attach/detach notifications
        CreateThread(nullptr, 0, MainThread, nullptr, 0, nullptr);  // Launch your logic
        break;
    case DLL_PROCESS_DETACH:
        if (h_driver != INVALID_HANDLE_VALUE)
        {
            CloseHandle(h_driver);
            h_driver = INVALID_HANDLE_VALUE;
        }
        break;
    }

    return TRUE;
}

